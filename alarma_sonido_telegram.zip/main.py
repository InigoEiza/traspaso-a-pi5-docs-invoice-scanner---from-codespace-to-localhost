#!/usr/bin/env python3
import threading
import time
import json
import os
import tkinter as tk
from tkinter import messagebox, simpledialog
from datetime import datetime

# Librerías de audio y red
try:
    import sounddevice as sd
    import numpy as np
except ImportError:
    sd = None
    np = None

import urllib.request
import urllib.parse

PASSWORD = "2348"
CONFIG_FILE = "config.json"


class SoundAlarmApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Alarma por sonido con Telegram")

        # Estado
        self.monitoring_active = False
        self.monitor_thread = None
        self.stop_event = threading.Event()
        self.current_config = {
            "telegram_bot_token": "",
            "telegram_chat_id": "",
            "threshold": 0.03,
            "seconds_required": 3.0,
            "sample_rate": 16000,
            "block_duration": 0.5,
        }

        self._load_config()

        # UI
        self._build_ui()

    def _build_ui(self):
        root = self.root

        frame = tk.Frame(root, padx=10, pady=10)
        frame.pack(fill="both", expand=True)

        # Telegram config
        tk.Label(frame, text="Token del bot de Telegram:").grid(row=0, column=0, sticky="w")
        self.token_entry = tk.Entry(frame, width=45, show="*")
        self.token_entry.grid(row=0, column=1, sticky="we", pady=2)

        tk.Label(frame, text="ID de chat de Telegram (número):").grid(row=1, column=0, sticky="w")
        self.chat_id_entry = tk.Entry(frame, width=25)
        self.chat_id_entry.grid(row=1, column=1, sticky="we", pady=2)

        # Sensibilidad
        tk.Label(frame, text="Sensibilidad (volumen umbral, típico 0.02 - 0.08):").grid(row=2, column=0, sticky="w")
        self.threshold_entry = tk.Entry(frame, width=10)
        self.threshold_entry.grid(row=2, column=1, sticky="w", pady=2)

        tk.Label(frame, text="Segundos de ruido continuos para disparar:").grid(row=3, column=0, sticky="w")
        self.seconds_entry = tk.Entry(frame, width=10)
        self.seconds_entry.grid(row=3, column=1, sticky="w", pady=2)

        # Botones
        button_frame = tk.Frame(frame)
        button_frame.grid(row=4, column=0, columnspan=2, pady=10)

        self.activate_button = tk.Button(button_frame, text="Activar alarma", command=self.activate_alarm)
        self.activate_button.pack(side="left", padx=5)

        self.deactivate_button = tk.Button(button_frame, text="Desactivar alarma", command=self.deactivate_alarm)
        self.deactivate_button.pack(side="left", padx=5)

        self.save_button = tk.Button(button_frame, text="Guardar configuración", command=self.save_config)
        self.save_button.pack(side="left", padx=5)

        # Estado
        self.status_label = tk.Label(frame, text="Estado: Inactiva", fg="red")
        self.status_label.grid(row=5, column=0, columnspan=2, sticky="w")

        # Info audio
        if sd is None or np is None:
            audio_text = "Librerías de audio no instaladas (sounddevice, numpy).\nLa detección de sonido no funcionará hasta que las instales."
        else:
            audio_text = "Micrófono listo. Ajusta la sensibilidad según tu entorno."

        self.info_label = tk.Label(frame, text=audio_text, fg="blue", justify="left")
        self.info_label.grid(row=6, column=0, columnspan=2, sticky="w", pady=(10,0))

        # Ajustar pesos de columnas
        frame.columnconfigure(1, weight=1)

        # Rellenar campos con config
        self._update_entries_from_config()

        # Cerrar limpio
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def _update_entries_from_config(self):
        self.token_entry.delete(0, tk.END)
        self.token_entry.insert(0, self.current_config.get("telegram_bot_token", ""))

        self.chat_id_entry.delete(0, tk.END)
        self.chat_id_entry.insert(0, self.current_config.get("telegram_chat_id", ""))

        self.threshold_entry.delete(0, tk.END)
        self.threshold_entry.insert(0, str(self.current_config.get("threshold", 0.03)))

        self.seconds_entry.delete(0, tk.END)
        self.seconds_entry.insert(0, str(self.current_config.get("seconds_required", 3.0)))

    def _load_config(self):
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                self.current_config.update(data)
            except Exception as e:
                print("No se pudo leer config.json:", e)

    def save_config(self):
        self._read_entries_to_config()
        try:
            with open(CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump(self.current_config, f, indent=2, ensure_ascii=False)
            messagebox.showinfo("Configuración", "Configuración guardada en config.json")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar config.json:\n{e}")

    def _read_entries_to_config(self):
        self.current_config["telegram_bot_token"] = self.token_entry.get().strip()
        self.current_config["telegram_chat_id"] = self.chat_id_entry.get().strip()

        try:
            self.current_config["threshold"] = float(self.threshold_entry.get().strip().replace(",", "."))
        except ValueError:
            self.current_config["threshold"] = 0.03

        try:
            self.current_config["seconds_required"] = float(self.seconds_entry.get().strip().replace(",", "."))
        except ValueError:
            self.current_config["seconds_required"] = 3.0

    def activate_alarm(self):
        if self.monitoring_active:
            messagebox.showinfo("Alarma", "La alarma ya está activa.")
            return

        if sd is None or np is None:
            messagebox.showerror(
                "Error",
                "No se encontraron las librerías 'sounddevice' y/o 'numpy'.\n"
                "Instálalas con:\n\npip install sounddevice numpy"
            )
            return

        self._read_entries_to_config()

        if not self.current_config["telegram_bot_token"] or not self.current_config["telegram_chat_id"]:
            messagebox.showerror("Error", "Rellena el token del bot y el ID de chat de Telegram.")
            return

        self.stop_event.clear()
        self.monitor_thread = threading.Thread(target=self._monitor_audio_loop, daemon=True)
        self.monitor_thread.start()
        self.monitoring_active = True
        self.status_label.config(text="Estado: Activada", fg="green")

    def deactivate_alarm(self):
        if not self.monitoring_active:
            messagebox.showinfo("Alarma", "La alarma ya está desactivada.")
            return

        pwd = simpledialog.askstring("Contraseña", "Introduce la contraseña para desactivar:", show="*")
        if pwd is None:
            return  # cancelado
        if pwd != PASSWORD:
            messagebox.showerror("Error", "Contraseña incorrecta.")
            return

        self._stop_monitoring()

    def _stop_monitoring(self):
        if self.monitoring_active:
            self.stop_event.set()
            self.monitoring_active = False
            self.status_label.config(text="Estado: Inactiva", fg="red")

    def _monitor_audio_loop(self):
        threshold = float(self.current_config.get("threshold", 0.03))
        seconds_required = float(self.current_config.get("seconds_required", 3.0))
        sample_rate = int(self.current_config.get("sample_rate", 16000))
        block_duration = float(self.current_config.get("block_duration", 0.5))

        frames_per_block = int(sample_rate * block_duration)
        noisy_time = 0.0
        alerted = False

        try:
            with sd.InputStream(channels=1, samplerate=sample_rate):
                while not self.stop_event.is_set():
                    data, overflowed = sd.InputStream.read(sd.InputStream, frames_per_block)
        except Exception:
            # Fallback a la forma correcta usando un stream explícito
            pass

        # Implementación correcta con stream explícito:
        try:
            with sd.InputStream(channels=1, samplerate=sample_rate) as stream:
                while not self.stop_event.is_set():
                    data, overflowed = stream.read(frames_per_block)
                    if overflowed:
                        print("Advertencia: overflow de audio.")

                    try:
                        rms = float(np.sqrt(np.mean(np.square(data))))
                    except Exception:
                        rms = 0.0

                    # Depuración opcional:
                    # print("RMS:", rms)

                    if rms > threshold:
                        noisy_time += block_duration
                    else:
                        noisy_time = 0.0

                    if noisy_time >= seconds_required and not alerted:
                        self._on_noise_detected(rms, noisy_time)
                        alerted = True
                    # Para permitir una nueva alerta tras silencio:
                    if noisy_time == 0.0 and alerted:
                        alerted = False

                    # Pequeña pausa por si acaso
                    if self.stop_event.wait(0.01):
                        break
        except Exception as e:
            print("Error en monitor de audio:", e)
            self.root.after(0, lambda: messagebox.showerror("Error audio", f"Error en el monitor de audio:\n{e}"))
            self.root.after(0, self._stop_monitoring)

    def _on_noise_detected(self, rms, noisy_time):
        print(f"Ruido detectado: rms={rms:.4f}, tiempo={noisy_time:.1f}s")
        # Enviar mensaje Telegram
        try:
            self._send_telegram_alert()
        except Exception as e:
            print("Error enviando a Telegram:", e)

    def _send_telegram_alert(self):
        token = self.current_config.get("telegram_bot_token", "").strip()
        chat_id = self.current_config.get("telegram_chat_id", "").strip()
        if not token or not chat_id:
            return

        message = f"Alarma de sonido: se ha detectado ruido durante al menos {self.current_config.get('seconds_required', 3.0)} segundos.\nHora: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"

        url = f"https://api.telegram.org/bot{token}/sendMessage"
        data = urllib.parse.urlencode({
            "chat_id": chat_id,
            "text": message
        }).encode("utf-8")

        req = urllib.request.Request(url, data=data, method="POST")
        with urllib.request.urlopen(req, timeout=10) as resp:
            resp.read()  # no usamos la respuesta, solo para lanzar la petición

    def on_close(self):
        self._stop_monitoring()
        self.root.destroy()


def main():
    root = tk.Tk()
    app = SoundAlarmApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
