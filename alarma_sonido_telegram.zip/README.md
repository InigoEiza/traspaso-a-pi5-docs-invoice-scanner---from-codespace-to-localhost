# Alarma por detección de sonido con notificación por Telegram

Script en Python que detecta ruido con el micrófono, y si hay ruido continuo durante X segundos,
envía una notificación por Telegram. La alarma se puede desactivar con un botón que pide contraseña
(contraseña fija: **2348**).

Pensado para correr, por ejemplo, en una Raspberry Pi 5 (o cualquier PC) y acceder por remoto
(mediante Tailscale o similar). La detección usa el micrófono del equipo donde se ejecuta el script.

---

## Requisitos

- Python 3
- Librerías:
  - `sounddevice`
  - `numpy`

Instalación (en la carpeta del proyecto):

```bash
pip install -r requirements.txt
```

En algunas plataformas puede que necesites también librerías del sistema:
- En Debian/Raspberry Pi OS, por ejemplo:
  ```bash
  sudo apt-get install python3-tk portaudio19-dev
  ```

---

## Cómo configurar el bot de Telegram

1. Abre Telegram y busca el usuario **@BotFather**.
2. Ejecuta `/newbot` y sigue las instrucciones para crear un bot nuevo.
3. Al final, BotFather te dará un **token** de tu bot, parecido a:
   `123456789:ABCDefghIJKlmnoPQRstuVWxyZ`
4. Copia ese token y pégalo en el campo **Token del bot de Telegram** en la aplicación.

### Obtener tu ID de chat (número de Telegram)

Hay varias formas; una sencilla es usar el bot @userinfobot:

1. En Telegram, busca **@userinfobot**.
2. Pulsa **Start**.
3. El bot te mostrará tu `Id`. Ese es el número que debes poner en el campo
   **ID de chat de Telegram (número)** de la app.

> También puedes usar el ID de un grupo si añades el bot al grupo, pero para lo básico es suficiente tu ID personal.

---

## Uso

1. Copia los archivos del proyecto a una carpeta, por ejemplo `alarma_sonido_telegram`.
2. Instala las dependencias:
   ```bash
   pip install -r requirements.txt
   ```
3. Ejecuta el programa:
   ```bash
   python main.py
   ```

4. En la ventana:
   - Rellena **Token del bot de Telegram**.
   - Rellena **ID de chat de Telegram (número)**.
   - Ajusta la **sensibilidad** (umbral):
     - Valores típicos entre `0.02` y `0.08`.
     - Cuanto más **bajo** el número, más sensible (dispara con menos ruido).
   - Ajusta los **segundos de ruido** continuos para disparar (por defecto 3).
   - Pulsa **Guardar configuración** si quieres que se guarde en `config.json`.
   - Pulsa **Activar alarma** para empezar a escuchar.

5. Cuando haya ruido por encima del umbral durante al menos X segundos seguidos,
   se enviará un mensaje a tu Telegram indicando que se ha detectado ruido y la hora.

6. Para desactivar la alarma:
   - Pulsa **Desactivar alarma**.
   - Introduce la contraseña: `2348`.

---

## Notas

- Si el micrófono o las librerías de audio no están bien instaladas, aparecerá un mensaje de error.
- Puedes dejar esto ejecutándose en una Raspberry Pi y conectarte por escritorio remoto
  para ver la ventana, o simplemente arrancarlo en segundo plano con `screen`/`tmux`.
- El programa está hecho en **Tkinter**, que viene con Python en la mayoría de sistemas.
